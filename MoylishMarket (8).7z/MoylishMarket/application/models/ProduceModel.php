<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProduceModel extends CI_Model
{
    function __construct()
    {	parent::__construct();
		$this->load->database();
    }
	
	//function to retrieve a record based on an ID
	function getProduceByID() {
        $produceCode = $this->input->post('produceCode');
        $resultSet = $this->db->get_where('products', array('produceCode' => $produceCode));
        if ($resultSet->num_rows() > 0 ) {
            $row = $resultSet->row_array();
            return $row;
        }
        else {
            return null;
        }
    }
}
?>