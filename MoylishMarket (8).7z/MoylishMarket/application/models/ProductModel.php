<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ProductModel extends CI_Model
{  function __construct()
    {	parent::__construct();
		$this->load->database();
    }
	
		function insertProductModel($product)
	{	$this->db->insert('products',$product);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

	function get_all_products() 
	{	$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,photo"); 
		$this->db->from('products');
		$query = $this->db->get();
		return $query->result();
	}
	
	public function deleteProductModel($id)
	{	$this->db->where('produceCode', $id);
		return $this->db->delete('products');
    }

	function updateProductModel($product,$id)
	{	$this->db->where('produceCode', $id);
		return $this->db->update('products', $product);
	}

	public function drilldown($product)
	{	$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,photo"); 
		$this->db->from('products');
		$this->db->where('produceCode',$product);
		$query = $this->db->get();
		return $query->result();
    }
    
	

	


    public function validate_product($post)
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('product_description', 'Product Description', 'required|is_unique[products.description]|min_length[3]');
		if($this->form_validation->run() === FALSE)
		{
			return FALSE;
		}
		else
		{
			return TRUE;
		}
	}



	
	public function find_product_by_name($name)
	{
		$query = "SELECT * FROM products WHERE name = ?";
		$values = array($name);
		return $this->db->query($query,$values)->row_array();
	}


	
	
	public function display_product_users($product_id)
	{
		$query = "SELECT users.name
				  FROM wishlist JOIN users on wishlist.user_id = users.id
				  WHERE wishlist.product_id = ?";
		$values = array($product_id);
		return $this->db->query($query, $values)->result_array();
	}
	public function display_product($producceCode)
	{
		$query = "SELECT Description
				  FROM products
				  WHERE produceCode = ?";
		$values = array($produceCode);
		return $this->db->query($query, $values)->row_array();
	}

	    
    
		public function getAllWishes($customerNumber){
		$query = "SELECT description, customers.FirstName, products.supplier, products.produceCode, added_by FROM produces JOIN customers ON products.produceLine = customers.customerNumber  WHERE products.produceCode NOT IN (SELECT produceCode FROM wishlists WHERE customerNumber = $customerNumber) ORDER BY products.produceLine DESC";
		return $this->db->query($query)->result_array();
	}
	public function getWishesbyId($id){
		$query = "SELECT , customers.FirstName,  customerNumber, produceCode FROM  JOIN wishlists ON items.id = wishlists.wishlistId JOIN users ON products.LastName = customer.id WHERE wishlists.customerId = $id";
		return $this->db->query($query)->result_array();
	}

	public function addtoWishlist($customerNumber, $produceCode){
		$query = "INSERT INTO wishlists (customerNumber, produceCode) VALUES (?,?)";
		$values = array($customerNumber, $produceCode);
		$this->db->query($query, $values);
	}

	
	function get_search_products ($description)
	{
		$query = $this->db->like('description',$description)->get('products');
		
		return $query->result();
	}
}
?>