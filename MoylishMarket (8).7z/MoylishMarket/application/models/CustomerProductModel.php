<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CustomerProductModel extends CI_Model
{
    function __construct()
    {	parent::__construct();
		$this->load->database();
    }
    	function get_all_Products() 
	{	$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,photo"); 
		$this->db->from('products');
		$query = $this->db->get();
		return $query->result();
	}
	public function drilldown($produceCode)
	{
		$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,photo");
		$this->db->from('products');
		$this->db->where('produceCode',$produceCode);
		$query = $this->db->get();
		return $query->result();
		
	}