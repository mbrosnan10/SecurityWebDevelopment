<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class CustomerModel extends CI_Model
{
    function __construct()
    {	parent::__construct();
		$this->load->database();
    }
    function get_all_Products() 
	{	$this->db->select("produceCode,description,productLine,supplier,quantityInStock,bulkBuyPrice,bulkSalePrice,photo"); 
		$this->db->from('products');
		$query = $this->db->get();
		return $query->result();
	}
public function drilldown2($customerNumber)
	{	$this->db->select("customerNumber,customerName,contactLastName,contactFirstName"); 
		$this->db->from('customers');
		$this->db->where('customerNumber',$customerNumber);
		$query = $this->db->get();
		return $query->result();
    }

	function insertCustomerModel($customer)
	{	$this->db->insert('customers',$customer);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}
	public function drilldown($customerNumber)
	{
		$this->db->select("customerNumber,customerName,contactLastName,contactFirstName,phone,addressLne1,addressLine2,city,postalCode,country,creditLimit,email,password");
		$this->db->from('customers');
		$this->db->where('customerNumber',$customerNumber);
		$query = $this->db->get();
		return $query->result();
		
	}
	//function to retrieve a record based on an ID
	function getCustomerByID() {
        $id = $this->input->post('customerNumber');
        $resultSet = $this->db->get_where('customers', array('customerNumber' => $id));
        if ($resultSet->num_rows() > 0 ) {
            $row = $resultSet->row_array();
            return $row;
        }
        else {
            return null;
        }
    }
	
	//sessions 2018
	//function to check if we have a valid user
	function login($email, $password) {
		$this -> db -> select('customerNumber, email, password');
		$this -> db -> from('customers');
		$this -> db -> where('email', $email);
		$this -> db -> where('password', $password);
		$this -> db -> limit(1);
		$query = $this -> db -> get();
		if($query -> num_rows() == 1) 
			return $query->result();
	   else
			return false;
	}	

}
?>