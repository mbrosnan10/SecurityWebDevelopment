<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class PaymentModel extends CI_Model
{  function __construct()
    {	parent::__construct();
		$this->load->database();
    }
    	function insertPaymentModel($payment)
	{	$this->db->insert('payments',$payment);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

    public function drilldown($payment)
	{	$this->db->select("customerNumber, cardType, cardNumber, cardName, expiryDate, CVV, checkNumber, paymentDate, amount, orderNumber"); 
		$this->db->from('payments');
		$this->db->where('customerNumber',$payment);
		$query = $this->db->get();
		return $query->result();
    }
}