<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class CustomerDetailModel extends CI_Model
{  function __construct()
    {	
    	parent::__construct();
		$this->load->database();
    }
    public function drilldown($customer)
	{	$this->db->select("customerNumber,customerName,contactFirstName,contactLastName,phone,addressLine1,addressLine2,city,postalCode,country,creditLimit,email,password"); 
		$this->db->from('customers');
		$this->db->where('customerNumber',$customer);
		$query = $this->db->get();
		return $query->result();
    }	
    function get_all_cutomers() 
	{	$this->db->select("customerNumber,customerName,contactFirstName,contactLastName,phone,addressLine1,addressLine2,city,postalCode,country,creditLimit,email,password"); 
		$this->db->from('customers');
		$query = $this->db->get();
		return $query->result();
	}
}
	
	