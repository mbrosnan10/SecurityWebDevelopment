<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class OrderModel extends CI_Model
{  function __construct()
    {	parent::__construct();
		$this->load->database();
    }
    	function insertOrderModel($order)
	{	$this->db->insert('orders',$order);
		if ($this->db->affected_rows() ==1) {
			return true;
		}
		else {
			return false;
		}
	}

	function get_all_orders() 
	{	$this->db->select("orderNumber,orderDate,requiredDate,shippedDate,status,comments,customerNumber"); 
		$this->db->from('orders');
		$query = $this->db->get();
		return $query->result();
	}
	
	


	public function drilldown2($order)
	{	$this->db->select("orderNumber,orderDate,requiredDate,shippedDate,status,comments,customerNumber"); 
		$this->db->from('orders');
		$this->db->where('orderNumber',$product);
		$query = $this->db->get();
		return $query->result();
    }
    
    }
?>